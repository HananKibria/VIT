"""
TRAIN ACTION-CONDITIONED WORLD MODEL ON DROID (62 hours)
=========================================================

Trains the full action-conditioned world model (encoder + predictor + 
autoregressive head + task classifier) on the DROID dataset, following
the V-JEPA 2 paper's protocol:

  - Downloads V-JEPA 2 pretrained ViT backbone as encoder initialization
  - Uses EMA target encoder for latent prediction targets (BYOL / V-JEPA style)
  - Skips episodes shorter than 4 seconds (< 60 frames at 15 Hz)
  - Trains on ~62 hours of manipulation data
  - Action dim = 7 (6D Cartesian target + 1 gripper)
  - State dim = 14 (7 joint + 6 Cartesian + 1 gripper)

Training Objectives:
  1. Latent prediction loss (V-JEPA style) — predict future encoder features
     from past observations + actions, using EMA target encoder as ground truth
  2. Action prediction loss — predict future actions from predictor output
  3. State prediction loss  — predict future robot states
  4. Task classification loss — predict manipulation success / failure

Usage:
    # From RLDS (Google Cloud or local):
    python train_action_conditioned_world_model.py \\
        --data_path gs://gresearch/robotics/droid \\
        --format rlds

    # From HuggingFace LeRobot:
    python train_action_conditioned_world_model.py \\
        --data_path cadene/droid \\
        --format huggingface

    # From local HDF5 files:
    python train_action_conditioned_world_model.py \\
        --data_path ./data/droid_hdf5 \\
        --format hdf5

    # Quick debug (100 episodes):
    python train_action_conditioned_world_model.py \\
        --data_path ./data/droid_hdf5 \\
        --format hdf5 \\
        --max_episodes 100 \\
        --num_epochs 2 \\
        --batch_size 2

Requirements:
    pip install torch torchvision numpy opencv-python tqdm h5py
    # For RLDS:   pip install tensorflow tensorflow_datasets
    # For HF:     pip install datasets
    # For V-JEPA: pip install transformers  (HuggingFace fallback)
"""

import math
import copy
import json
import argparse
import os
from pathlib import Path
from typing import Optional, Dict

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader, ConcatDataset
from torchvision import transforms
import numpy as np
import cv2
from tqdm import tqdm

from droid_world_model import DROIDActionConditionedWorldModel, VideoViTEncoder


# ============================================================================
# CONSTANTS — DROID Dataset
# ============================================================================

DROID_FPS = 15                          # DROID capture rate
MIN_EPISODE_SECONDS = 4                 # V-JEPA 2 paper: skip < 4s
MIN_EPISODE_FRAMES = MIN_EPISODE_SECONDS * DROID_FPS  # = 60 frames
TARGET_HOURS = 62                       # V-JEPA 2 used 62 h of DROID
TARGET_FRAMES = int(TARGET_HOURS * 3600 * DROID_FPS)  # ≈ 3.35 M frames

IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD  = [0.229, 0.224, 0.225]


# ============================================================================
# V-JEPA 2 BACKBONE DOWNLOAD
# ============================================================================

def download_vjepa2_backbone(model_size='vitl', resolution=256):
    """
    Download V-JEPA 2 pretrained ViT encoder.

    Args:
        model_size: 'vitl' (300M, recommended), 'vith' (600M), 'vitg' (1B)
        resolution: 256 or 384

    Returns:
        state_dict: encoder weights (prefix-stripped)
        config: dict with embed_dim, depth, num_heads
    """
    config_map = {
        'vitl': {'embed_dim': 1024, 'depth': 24, 'num_heads': 16, 'hub': 'vjepa2_vitl'},
        'vith': {'embed_dim': 1280, 'depth': 32, 'num_heads': 16, 'hub': 'vjepa2_vith'},
        'vitg': {'embed_dim': 1024, 'depth': 40, 'num_heads': 16, 'hub': 'vjepa2_vitg'},
    }
    if model_size not in config_map:
        raise ValueError(f"Unknown model_size '{model_size}'. Choose: {list(config_map.keys())}")

    cfg = config_map[model_size]
    print(f"\n[backbone] Downloading V-JEPA 2 {model_size.upper()} ({cfg['embed_dim']}d, "
          f"{cfg['depth']} layers, {cfg['num_heads']} heads)")

    # --- Try torch.hub first ---
    try:
        print(f"  → torch.hub: facebookresearch/vjepa2 / {cfg['hub']}")
        encoder = torch.hub.load('facebookresearch/vjepa2', cfg['hub'], trust_repo=True)
        raw_sd = encoder.state_dict()
    except Exception as e:
        print(f"  torch.hub failed: {e}")

        # --- Fallback: HuggingFace ---
        try:
            from transformers import AutoModel
            hf_id = f'facebook/vjepa2-{model_size}-fpc64-{resolution}'
            print(f"  → HuggingFace: {hf_id}")
            model = AutoModel.from_pretrained(hf_id, trust_remote_code=True)
            raw_sd = model.encoder.state_dict()
        except Exception as e2:
            raise RuntimeError(
                f"Could not download V-JEPA 2.\n"
                f"  torch.hub error: {e}\n"
                f"  HuggingFace error: {e2}\n\n"
                f"Ensure internet access and install `transformers`.\n"
                f"Or download manually from https://github.com/facebookresearch/vjepa2"
            )

    # Strip 'encoder.' prefix if present
    adapted_sd = {}
    for k, v in raw_sd.items():
        new_k = k.replace('encoder.', '').replace('module.', '')
        adapted_sd[new_k] = v

    print(f"  ✓ Loaded {len(adapted_sd)} parameter tensors")
    return adapted_sd, {k: cfg[k] for k in ('embed_dim', 'depth', 'num_heads')}


# ============================================================================
# DROID DATASET — with ≥4 second filter
# ============================================================================

class ManipulationVideoAugmentation:
    """
    DROID video augmentation.
    - Horizontal flip allowed (manipulation is symmetric)
    - No vertical flip (gravity matters)
    - Consistent spatial transform across all frames in a clip
    """

    def __init__(self, img_size=224, training=True, strength='medium'):
        self.img_size = img_size
        self.training = training

        if training:
            cfgs = {
                'light':  {'scale': (0.9, 1.0), 'rot': 5,  'bri': 0.1, 'con': 0.1},
                'medium': {'scale': (0.7, 1.0), 'rot': 10, 'bri': 0.2, 'con': 0.15},
                'heavy':  {'scale': (0.6, 1.0), 'rot': 15, 'bri': 0.3, 'con': 0.2},
            }
            c = cfgs.get(strength, cfgs['medium'])
            self.spatial_transform = transforms.Compose([
                transforms.RandomResizedCrop(img_size, scale=c['scale']),
                transforms.RandomHorizontalFlip(p=0.5),
                transforms.RandomRotation(degrees=c['rot']),
                transforms.ColorJitter(brightness=c['bri'], contrast=c['con']),
            ])
        else:
            self.spatial_transform = transforms.Compose([
                transforms.Resize(img_size),
                transforms.CenterCrop(img_size),
            ])

        self.normalize = transforms.Normalize(mean=IMAGENET_MEAN, std=IMAGENET_STD)

    def __call__(self, video_frames):
        """List of np arrays (H,W,3) uint8 → (C, T, H, W) float32 normalized."""
        # Compute consistent crop for all frames
        first = transforms.ToPILImage()(video_frames[0]) if isinstance(video_frames[0], np.ndarray) else video_frames[0]
        if self.training:
            crop_params = transforms.RandomResizedCrop.get_params(
                first,
                self.spatial_transform.transforms[0].scale,
                self.spatial_transform.transforms[0].ratio,
            )

        augmented = []
        for frame in video_frames:
            if isinstance(frame, np.ndarray):
                frame = transforms.ToPILImage()(frame)
            if self.training:
                frame = transforms.functional.resized_crop(
                    frame, *crop_params, (self.img_size, self.img_size))
                for t in self.spatial_transform.transforms[1:]:
                    frame = t(frame)
            else:
                frame = self.spatial_transform(frame)

            frame = transforms.ToTensor()(frame)
            frame = self.normalize(frame)
            augmented.append(frame)

        return torch.stack(augmented, dim=0).permute(1, 0, 2, 3)  # (C, T, H, W)


class DROIDDatasetRLDS(Dataset):
    """DROID RLDS loader with ≥4s filter."""

    def __init__(self, data_path, num_frames=16, img_size=224,
                 camera='exterior_image_1_left', training=True,
                 augmentation_strength='medium', max_episodes=None,
                 predict_horizon=4):
        self.num_frames = num_frames
        self.img_size = img_size
        self.camera = camera
        self.training = training
        self.predict_horizon = predict_horizon
        self.clip_length = num_frames + predict_horizon  # need future frames for targets

        try:
            import tensorflow_datasets as tfds
        except ImportError:
            raise ImportError("pip install tensorflow tensorflow_datasets")

        print(f"[RLDS] Loading DROID from: {data_path}")
        ds = tfds.load("droid", data_dir=data_path, split="train")

        self.episodes = []
        total_frames = 0
        skipped = 0
        for i, episode in enumerate(ds):
            if max_episodes and len(self.episodes) >= max_episodes:
                break
            steps = list(episode['steps'])
            ep_len = len(steps)
            duration_sec = ep_len / DROID_FPS

            if duration_sec < MIN_EPISODE_SECONDS:
                skipped += 1
                continue
            if ep_len < self.clip_length:
                skipped += 1
                continue

            self.episodes.append(steps)
            total_frames += ep_len

            if total_frames >= TARGET_FRAMES:
                print(f"  Reached {TARGET_HOURS}h target ({total_frames/DROID_FPS/3600:.1f}h)")
                break

        self.samples = self._create_samples()
        self.augmentation = ManipulationVideoAugmentation(img_size, training, augmentation_strength)

        print(f"  Episodes: {len(self.episodes)} (skipped {skipped} < {MIN_EPISODE_SECONDS}s)")
        print(f"  Total: {total_frames/DROID_FPS/3600:.1f} hours, {len(self.samples)} clips")

    def _create_samples(self):
        samples = []
        stride = max(1, self.num_frames // 2)
        for ep_idx, steps in enumerate(self.episodes):
            for start in range(0, len(steps) - self.clip_length + 1, stride):
                samples.append({'episode_idx': ep_idx, 'start': start})
        return samples

    def _load_clip(self, episode_idx, start, length):
        steps = self.episodes[episode_idx]
        frames, actions, states = [], [], []
        for i in range(length):
            step = steps[start + i]
            frames.append(step['observation'][self.camera].numpy())
            actions.append(step['action'].numpy())
            joint = step['observation']['joint_position'].numpy()
            cart = step['observation']['cartesian_position'].numpy()
            grip = step['observation']['gripper_position'].numpy()
            states.append(np.concatenate([joint, cart, grip]))
        return frames, np.stack(actions), np.stack(states)

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        s = self.samples[idx]
        frames, actions, states = self._load_clip(
            s['episode_idx'], s['start'], self.clip_length)

        video = self.augmentation(frames[:self.num_frames])
        future_frames_raw = frames[self.num_frames:self.clip_length]
        future_video = self.augmentation(future_frames_raw) if len(future_frames_raw) > 0 else None

        actions = torch.from_numpy(actions).float()
        states = torch.from_numpy(states).float()

        result = {
            'video': video,                                  # (C, T, H, W)
            'actions': actions[:self.num_frames],             # (T, 7)
            'states': states[:self.num_frames],               # (T, 14)
            'future_actions': actions[self.num_frames:],      # (H, 7)
            'future_states': states[self.num_frames:],        # (H, 14)
        }
        if future_video is not None:
            result['future_video'] = future_video
        # Binary label: 1 = success if episode completed without failure
        # (approximation: use last-frame gripper state as proxy)
        result['task_label'] = torch.tensor(1, dtype=torch.long)  # placeholder
        return result


class DROIDDatasetHuggingFace(Dataset):
    """DROID HuggingFace LeRobot loader with ≥4s filter."""

    def __init__(self, data_path='cadene/droid', num_frames=16, img_size=224,
                 camera='observation.images.exterior_image_1_left',
                 training=True, augmentation_strength='medium',
                 max_episodes=None, predict_horizon=4):
        self.num_frames = num_frames
        self.img_size = img_size
        self.camera = camera
        self.training = training
        self.predict_horizon = predict_horizon
        self.clip_length = num_frames + predict_horizon

        try:
            from datasets import load_dataset
        except ImportError:
            raise ImportError("pip install datasets")

        print(f"[HuggingFace] Loading DROID from: {data_path}")

        ds = load_dataset(data_path, split="train", streaming=True)

        self.episodes = []
        current_ep = []
        current_ep_idx = -1
        total_frames = 0
        skipped = 0
        count = 0

        for row in ds:
            ep_idx = row.get('episode_index', 0)
            if ep_idx != current_ep_idx:
                if len(current_ep) > 0:
                    duration = len(current_ep) / DROID_FPS
                    if duration >= MIN_EPISODE_SECONDS and len(current_ep) >= self.clip_length:
                        self.episodes.append(current_ep)
                        total_frames += len(current_ep)
                    else:
                        skipped += 1

                    if max_episodes and len(self.episodes) >= max_episodes:
                        break
                    if total_frames >= TARGET_FRAMES:
                        break

                current_ep = []
                current_ep_idx = ep_idx
            current_ep.append(row)
            count += 1
            if count % 50000 == 0:
                print(f"  {count} frames, {len(self.episodes)} episodes, "
                      f"{total_frames/DROID_FPS/3600:.1f}h ...")

        # Handle last episode
        if len(current_ep) >= self.clip_length:
            duration = len(current_ep) / DROID_FPS
            if duration >= MIN_EPISODE_SECONDS:
                self.episodes.append(current_ep)
                total_frames += len(current_ep)
            else:
                skipped += 1

        self.samples = self._create_samples()
        self.augmentation = ManipulationVideoAugmentation(img_size, training, augmentation_strength)

        print(f"  Episodes: {len(self.episodes)} (skipped {skipped} < {MIN_EPISODE_SECONDS}s)")
        print(f"  Total: {total_frames/DROID_FPS/3600:.1f} hours, {len(self.samples)} clips")

    def _create_samples(self):
        samples = []
        stride = max(1, self.num_frames // 2)
        for ep_idx, ep in enumerate(self.episodes):
            for start in range(0, len(ep) - self.clip_length + 1, stride):
                samples.append({'episode_idx': ep_idx, 'start': start})
        return samples

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        s = self.samples[idx]
        ep = self.episodes[s['episode_idx']]
        frames, actions, states = [], [], []

        for i in range(self.clip_length):
            row = ep[s['start'] + i]
            img = np.array(row[self.camera])
            if img.ndim == 2:
                img = np.stack([img] * 3, axis=-1)
            frames.append(img)
            actions.append(np.array(row['action'], dtype=np.float32))
            states.append(np.array(row['observation.state'], dtype=np.float32))

        video = self.augmentation(frames[:self.num_frames])
        future_video = self.augmentation(frames[self.num_frames:]) if self.predict_horizon > 0 else None

        actions = torch.from_numpy(np.stack(actions)).float()
        states = torch.from_numpy(np.stack(states)).float()

        result = {
            'video': video,
            'actions': actions[:self.num_frames],
            'states': states[:self.num_frames],
            'future_actions': actions[self.num_frames:],
            'future_states': states[self.num_frames:],
            'task_label': torch.tensor(1, dtype=torch.long),
        }
        if future_video is not None:
            result['future_video'] = future_video
        return result


class DROIDDatasetHDF5(Dataset):
    """DROID HDF5 loader with ≥4s filter."""

    def __init__(self, data_path, num_frames=16, img_size=224,
                 camera='exterior_image_1_left', training=True,
                 augmentation_strength='medium', max_episodes=None,
                 predict_horizon=4):
        self.data_path = Path(data_path)
        self.num_frames = num_frames
        self.img_size = img_size
        self.camera = camera
        self.training = training
        self.predict_horizon = predict_horizon
        self.clip_length = num_frames + predict_horizon

        try:
            import h5py
            self.h5py = h5py
        except ImportError:
            raise ImportError("pip install h5py")

        all_files = sorted(self.data_path.glob('**/*.hdf5')) + \
                    sorted(self.data_path.glob('**/*.h5'))
        if not all_files:
            raise FileNotFoundError(f"No HDF5 files in {data_path}")

        # Filter: ≥4 seconds and ≥ clip_length frames
        self.hdf5_files = []
        total_frames = 0
        skipped = 0

        for fpath in all_files:
            ep_len = self._get_episode_length(fpath)
            duration_sec = ep_len / DROID_FPS

            if duration_sec < MIN_EPISODE_SECONDS or ep_len < self.clip_length:
                skipped += 1
                continue

            self.hdf5_files.append(fpath)
            total_frames += ep_len

            if max_episodes and len(self.hdf5_files) >= max_episodes:
                break
            if total_frames >= TARGET_FRAMES:
                print(f"  Reached {TARGET_HOURS}h target ({total_frames/DROID_FPS/3600:.1f}h)")
                break

        self.samples = self._create_samples()
        self.augmentation = ManipulationVideoAugmentation(img_size, training, augmentation_strength)

        print(f"[HDF5] Episodes: {len(self.hdf5_files)} (skipped {skipped} < {MIN_EPISODE_SECONDS}s)")
        print(f"  Total: {total_frames/DROID_FPS/3600:.1f} hours, {len(self.samples)} clips")

    def _get_episode_length(self, fpath):
        try:
            with self.h5py.File(fpath, 'r') as f:
                for key in ['action', 'actions', 'action/cartesian_position']:
                    if key in f:
                        return f[key].shape[0]
            return 0
        except:
            return 0

    def _create_samples(self):
        samples = []
        stride = max(1, self.num_frames // 2)
        for fi, fpath in enumerate(self.hdf5_files):
            ep_len = self._get_episode_length(fpath)
            for start in range(0, ep_len - self.clip_length + 1, stride):
                samples.append({'file_idx': fi, 'start': start})
        return samples

    def _load_clip(self, file_idx, start):
        fpath = self.hdf5_files[file_idx]
        end = start + self.clip_length

        with self.h5py.File(fpath, 'r') as f:
            # --- Images ---
            img_data = None
            for img_key in [
                f'obs/{self.camera}',
                f'observation/{self.camera}/image_left',
                f'observation/exterior_image_1/image_left',
                f'observation/wrist_image/image_left',
                self.camera,
            ]:
                if img_key in f:
                    img_data = f[img_key][start:end]
                    break

            if img_data is None:
                # Fallback: find any 4D dataset (T, H, W, C)
                def find_images(group, prefix=''):
                    for k in group.keys():
                        path = f"{prefix}/{k}" if prefix else k
                        if isinstance(group[k], self.h5py.Dataset) and group[k].ndim == 4:
                            return path
                        elif isinstance(group[k], self.h5py.Group):
                            r = find_images(group[k], path)
                            if r:
                                return r
                    return None
                img_key = find_images(f)
                if img_key:
                    img_data = f[img_key][start:end]
                else:
                    raise KeyError(f"No image data in {fpath}")

            frames = [img_data[i] for i in range(self.clip_length)]

            # --- Actions (7D) ---
            if 'action' in f and f['action'].ndim == 2:
                raw_actions = f['action'][start:end]
            elif 'action/cartesian_position' in f:
                cart_a = f['action/cartesian_position'][start:end]
                grip_a = f['action/gripper_position'][start:end]
                raw_actions = np.concatenate([cart_a, grip_a], axis=-1)
            elif 'actions' in f:
                raw_actions = f['actions'][start:end]
            else:
                raw_actions = np.zeros((self.clip_length, 7), dtype=np.float32)

            # --- States (14D) ---
            if 'obs/joint_positions' in f:
                joint = f['obs/joint_positions'][start:end]
                cart = f['obs/cartesian_position'][start:end]
                grip = f['obs/gripper_position'][start:end]
                raw_states = np.concatenate([joint, cart, grip], axis=-1)
            elif 'observation/robot_state/joint_positions' in f:
                joint = f['observation/robot_state/joint_positions'][start:end]
                cart = f['observation/robot_state/cartesian_position'][start:end]
                grip = f['observation/robot_state/gripper_position'][start:end]
                raw_states = np.concatenate([joint, cart, grip], axis=-1)
            else:
                raw_states = np.zeros((self.clip_length, 14), dtype=np.float32)

        return frames, raw_actions.astype(np.float32), raw_states.astype(np.float32)

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        s = self.samples[idx]
        frames, actions, states = self._load_clip(s['file_idx'], s['start'])

        video = self.augmentation(frames[:self.num_frames])
        future_video = self.augmentation(frames[self.num_frames:]) if self.predict_horizon > 0 else None

        actions = torch.from_numpy(actions).float()
        states = torch.from_numpy(states).float()

        result = {
            'video': video,
            'actions': actions[:self.num_frames],
            'states': states[:self.num_frames],
            'future_actions': actions[self.num_frames:],
            'future_states': states[self.num_frames:],
            'task_label': torch.tensor(1, dtype=torch.long),
        }
        if future_video is not None:
            result['future_video'] = future_video
        return result


def create_dataset(args):
    """Factory: create dataset based on format."""
    common = dict(
        num_frames=args.num_frames,
        img_size=args.img_size,
        training=True,
        augmentation_strength=args.augmentation_strength,
        max_episodes=args.max_episodes,
        predict_horizon=args.predict_horizon,
    )
    if args.format == 'rlds':
        return DROIDDatasetRLDS(args.data_path, camera=args.camera, **common)
    elif args.format == 'huggingface':
        hf_cam = f'observation.images.{args.camera}'
        return DROIDDatasetHuggingFace(args.data_path, camera=hf_cam, **common)
    elif args.format == 'hdf5':
        return DROIDDatasetHDF5(args.data_path, camera=args.camera, **common)
    else:
        raise ValueError(f"Unknown format: {args.format}")


# ============================================================================
# EMA TARGET ENCODER (V-JEPA / BYOL style)
# ============================================================================

class EMAEncoder:
    """
    Exponential Moving Average of the encoder.
    Provides stable regression targets for latent prediction.
    No gradients flow through this encoder.
    """

    def __init__(self, encoder: nn.Module, decay: float = 0.999):
        self.ema_encoder = copy.deepcopy(encoder)
        self.ema_encoder.requires_grad_(False)
        self.decay = decay

    def update(self, encoder: nn.Module):
        with torch.no_grad():
            for ema_p, p in zip(self.ema_encoder.parameters(), encoder.parameters()):
                ema_p.data.mul_(self.decay).add_(p.data, alpha=1.0 - self.decay)

    @torch.no_grad()
    def encode(self, video):
        self.ema_encoder.eval()
        return self.ema_encoder(video)

    def to(self, device):
        self.ema_encoder.to(device)
        return self

    def state_dict(self):
        return self.ema_encoder.state_dict()

    def load_state_dict(self, sd):
        self.ema_encoder.load_state_dict(sd)


# ============================================================================
# LOSS FUNCTIONS
# ============================================================================

def latent_prediction_loss(predicted_features, target_features):
    """
    V-JEPA style: smooth-L1 in normalized latent space.
    Both inputs: (B, D) or (B, N, D).
    """
    pred = F.normalize(predicted_features, dim=-1)
    tgt = F.normalize(target_features, dim=-1)
    return F.smooth_l1_loss(pred, tgt)


def action_prediction_loss(pred_actions, gt_actions):
    """MSE on predicted vs ground-truth actions. (B, 7)."""
    return F.mse_loss(pred_actions, gt_actions)


def state_prediction_loss(pred_states, gt_states):
    """MSE on predicted vs ground-truth states. (B, 14)."""
    return F.mse_loss(pred_states, gt_states)


def task_classification_loss(logits, labels):
    """Cross-entropy for success/failure. (B, 2), (B,)."""
    return F.cross_entropy(logits, labels)


def uncertainty_regularization(uncertainties, min_val=0.01):
    """
    Encourage uncertainty estimates to not collapse to zero.
    Penalize if mean uncertainty drops below min_val.
    """
    mean_unc = uncertainties.mean()
    return F.relu(min_val - mean_unc)


# ============================================================================
# TRAINING LOOP
# ============================================================================

def train_action_conditioned_world_model(
    model: DROIDActionConditionedWorldModel,
    ema: EMAEncoder,
    dataloader: DataLoader,
    args,
):
    """
    Main training loop for the action-conditioned world model.

    Losses:
      L_total = λ_lat * L_latent + λ_act * L_action + λ_state * L_state
              + λ_task * L_task + λ_unc * L_uncertainty
    """
    device = args.device
    model.to(device)
    ema.to(device)

    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)

    # ---- Optimizer (separate LR for encoder vs predictor) ----
    encoder_params = list(model.encoder.parameters())
    predictor_params = [p for n, p in model.named_parameters()
                        if not n.startswith('encoder.')]

    param_groups = [
        {'params': encoder_params, 'lr': args.encoder_lr},
        {'params': predictor_params, 'lr': args.learning_rate},
    ]
    optimizer = torch.optim.AdamW(param_groups, weight_decay=args.weight_decay)

    # Cosine schedule with warmup
    total_steps = len(dataloader) * args.num_epochs
    warmup_steps = int(total_steps * args.warmup_ratio)

    def lr_lambda(step):
        if step < warmup_steps:
            return step / max(warmup_steps, 1)
        progress = (step - warmup_steps) / max(total_steps - warmup_steps, 1)
        return 0.5 * (1.0 + math.cos(math.pi * progress))

    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)

    # Loss weights
    λ_lat   = args.lambda_latent
    λ_act   = args.lambda_action
    λ_state = args.lambda_state
    λ_task  = args.lambda_task
    λ_unc   = args.lambda_uncertainty

    # Mixed precision
    scaler = torch.amp.GradScaler('cuda', enabled=(device == 'cuda' and args.use_amp))
    autocast_dtype = torch.float16 if args.use_amp else torch.float32

    best_loss = float('inf')
    global_step = 0

    # ---- Log config ----
    config = vars(args)
    config['total_steps'] = total_steps
    config['warmup_steps'] = warmup_steps
    config['num_samples'] = len(dataloader.dataset)
    with open(save_dir / 'config.json', 'w') as f:
        json.dump(config, f, indent=2, default=str)

    print(f"\n{'='*70}")
    print("ACTION-CONDITIONED WORLD MODEL TRAINING")
    print(f"{'='*70}")
    print(f"  Dataset:        {len(dataloader.dataset)} clips")
    print(f"  Batch size:     {args.batch_size}")
    print(f"  Epochs:         {args.num_epochs}")
    print(f"  Total steps:    {total_steps}")
    print(f"  Warmup:         {warmup_steps} steps ({args.warmup_ratio*100:.0f}%)")
    print(f"  Encoder LR:     {args.encoder_lr}")
    print(f"  Predictor LR:   {args.learning_rate}")
    print(f"  Predict horizon:{args.predict_horizon}")
    print(f"  EMA decay:      {args.ema_decay}")
    print(f"  Device:         {device}")
    print(f"  AMP:            {args.use_amp}")
    enc_params = sum(p.numel() for p in model.encoder.parameters()) / 1e6
    pred_params = sum(p.numel() for p in predictor_params) / 1e6
    print(f"  Encoder params: {enc_params:.1f}M")
    print(f"  Predictor params: {pred_params:.1f}M")
    print(f"  Loss weights:   lat={λ_lat} act={λ_act} state={λ_state} "
          f"task={λ_task} unc={λ_unc}")
    print(f"{'='*70}\n")

    for epoch in range(1, args.num_epochs + 1):
        model.train()
        epoch_losses = {k: 0.0 for k in
                        ['total', 'latent', 'action', 'state', 'task', 'uncertainty']}

        pbar = tqdm(dataloader, desc=f"Epoch {epoch}/{args.num_epochs}")

        for batch_idx, batch in enumerate(pbar):
            video       = batch['video'].to(device)              # (B, C, T, H, W)
            actions     = batch['actions'].to(device)            # (B, T, 7)
            states      = batch['states'].to(device)             # (B, T, 14)
            fut_actions = batch['future_actions'].to(device)     # (B, H, 7)
            fut_states  = batch['future_states'].to(device)      # (B, H, 14)
            task_label  = batch['task_label'].to(device)         # (B,)

            # Extend actions/states to cover prediction horizon
            all_actions = torch.cat([actions, fut_actions], dim=1)
            all_states  = torch.cat([states, fut_states], dim=1)

            optimizer.zero_grad(set_to_none=True)

            with torch.amp.autocast('cuda', dtype=autocast_dtype, enabled=(device == 'cuda' and args.use_amp)):

                # ---- Forward pass ----
                predictions, cur_logits, fut_logits = model(
                    video, all_actions, all_states,
                    predict_horizon=args.predict_horizon,
                    encoder_frozen=False,
                )

                # ---- 1. Latent prediction loss (V-JEPA style) ----
                # Target: EMA encoder features of the full video
                with torch.no_grad():
                    target_features = ema.encode(video)  # (B, N, D)
                    target_mean = target_features.mean(dim=1)  # (B, D)

                loss_latent = torch.tensor(0.0, device=device)
                for h_step, pred_dict in enumerate(predictions):
                    loss_latent = loss_latent + latent_prediction_loss(
                        pred_dict['features'], target_mean)
                if len(predictions) > 0:
                    loss_latent = loss_latent / len(predictions)

                # ---- 2. Action prediction loss ----
                loss_action = torch.tensor(0.0, device=device)
                for h_step, pred_dict in enumerate(predictions):
                    if h_step < fut_actions.shape[1]:
                        loss_action = loss_action + action_prediction_loss(
                            pred_dict['action'], fut_actions[:, h_step])
                if len(predictions) > 0:
                    loss_action = loss_action / len(predictions)

                # ---- 3. State prediction loss ----
                loss_state = torch.tensor(0.0, device=device)
                for h_step, pred_dict in enumerate(predictions):
                    if h_step < fut_states.shape[1]:
                        loss_state = loss_state + state_prediction_loss(
                            pred_dict['state'], fut_states[:, h_step])
                if len(predictions) > 0:
                    loss_state = loss_state / len(predictions)

                # ---- 4. Task classification loss ----
                loss_task = task_classification_loss(cur_logits, task_label)
                if fut_logits is not None:
                    loss_task = loss_task + task_classification_loss(fut_logits, task_label)
                    loss_task = loss_task / 2.0

                # ---- 5. Uncertainty regularization ----
                loss_unc = torch.tensor(0.0, device=device)
                for pred_dict in predictions:
                    loss_unc = loss_unc + uncertainty_regularization(
                        pred_dict['action_uncertainty'])
                    loss_unc = loss_unc + uncertainty_regularization(
                        pred_dict['state_uncertainty'])
                if len(predictions) > 0:
                    loss_unc = loss_unc / (2 * len(predictions))

                # ---- Total ----
                loss_total = (λ_lat * loss_latent
                              + λ_act * loss_action
                              + λ_state * loss_state
                              + λ_task * loss_task
                              + λ_unc * loss_unc)

            # ---- Backward + step ----
            scaler.scale(loss_total).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=args.grad_clip)
            scaler.step(optimizer)
            scaler.update()
            scheduler.step()

            # ---- EMA update ----
            ema.update(model.encoder)

            # ---- Track ----
            global_step += 1
            epoch_losses['total']       += loss_total.item()
            epoch_losses['latent']      += loss_latent.item()
            epoch_losses['action']      += loss_action.item()
            epoch_losses['state']       += loss_state.item()
            epoch_losses['task']        += loss_task.item()
            epoch_losses['uncertainty'] += loss_unc.item()

            pbar.set_postfix(
                loss=f"{loss_total.item():.4f}",
                lat=f"{loss_latent.item():.3f}",
                act=f"{loss_action.item():.3f}",
                st=f"{loss_state.item():.3f}",
                lr=f"{scheduler.get_last_lr()[1]:.2e}",
            )

            # ---- Periodic save ----
            if global_step % args.save_every_steps == 0:
                step_ckpt = {
                    'epoch': epoch,
                    'global_step': global_step,
                    'model_state_dict': model.state_dict(),
                    'ema_encoder_state_dict': ema.state_dict(),
                    'optimizer_state_dict': optimizer.state_dict(),
                    'scheduler_state_dict': scheduler.state_dict(),
                    'scaler_state_dict': scaler.state_dict(),
                    'config': config,
                }
                torch.save(step_ckpt, save_dir / f"step_{global_step}.pth")
                print(f"\n  💾 Saved step checkpoint: step_{global_step}.pth")

        # ---- Epoch summary ----
        n = max(len(dataloader), 1)
        avg = {k: v / n for k, v in epoch_losses.items()}

        print(f"\n  Epoch {epoch:02d} Summary:")
        print(f"    Total:   {avg['total']:.4f}")
        print(f"    Latent:  {avg['latent']:.4f}")
        print(f"    Action:  {avg['action']:.4f}")
        print(f"    State:   {avg['state']:.4f}")
        print(f"    Task:    {avg['task']:.4f}")
        print(f"    Uncert:  {avg['uncertainty']:.4f}")
        print(f"    LR enc:  {scheduler.get_last_lr()[0]:.2e}")
        print(f"    LR pred: {scheduler.get_last_lr()[1]:.2e}")

        # ---- Save checkpoint ----
        ckpt = {
            'epoch': epoch,
            'global_step': global_step,
            'model_state_dict': model.state_dict(),
            'ema_encoder_state_dict': ema.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'scheduler_state_dict': scheduler.state_dict(),
            'scaler_state_dict': scaler.state_dict(),
            'epoch_losses': avg,
            'config': config,
        }
        torch.save(ckpt, save_dir / f"epoch_{epoch:03d}.pth")

        if avg['total'] < best_loss:
            best_loss = avg['total']
            torch.save(ckpt, save_dir / "best_model.pth")
            print(f"    ★ New best model (loss={best_loss:.4f})")

    # ---- Final save ----
    torch.save(ckpt, save_dir / "final_model.pth")

    print(f"\n{'='*70}")
    print(f"TRAINING COMPLETE")
    print(f"  Best loss: {best_loss:.4f}")
    print(f"  Checkpoints: {save_dir}")
    print(f"{'='*70}\n")


# ============================================================================
# RESUME FROM CHECKPOINT
# ============================================================================

def resume_from_checkpoint(model, ema, optimizer, scheduler, scaler, ckpt_path, device):
    """Resume training from a saved checkpoint."""
    print(f"\n  Resuming from: {ckpt_path}")
    ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)
    model.load_state_dict(ckpt['model_state_dict'])
    ema.load_state_dict(ckpt['ema_encoder_state_dict'])
    optimizer.load_state_dict(ckpt['optimizer_state_dict'])
    scheduler.load_state_dict(ckpt['scheduler_state_dict'])
    if 'scaler_state_dict' in ckpt:
        scaler.load_state_dict(ckpt['scaler_state_dict'])
    start_epoch = ckpt['epoch'] + 1
    global_step = ckpt['global_step']
    print(f"  Resumed at epoch {start_epoch}, step {global_step}")
    return start_epoch, global_step


# ============================================================================
# MAIN
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description='Train Action-Conditioned World Model on DROID (62h, ≥4s)')

    # ---- Data ----
    g = parser.add_argument_group('Data')
    g.add_argument('--data_path', type=str, required=True,
                   help='DROID data path (GCS bucket / HuggingFace ID / local dir)')
    g.add_argument('--format', type=str, default='hdf5',
                   choices=['rlds', 'huggingface', 'hdf5'])
    g.add_argument('--camera', type=str, default='exterior_image_1_left',
                   help='Camera view (exterior_image_1_left, exterior_image_2_left, '
                        'wrist_image_left)')
    g.add_argument('--max_episodes', type=int, default=None,
                   help='Cap number of episodes (for debugging)')
    g.add_argument('--augmentation_strength', type=str, default='medium',
                   choices=['light', 'medium', 'heavy'])

    # ---- V-JEPA 2 backbone ----
    g = parser.add_argument_group('V-JEPA 2 Backbone')
    g.add_argument('--vjepa2_size', type=str, default='vitl',
                   choices=['vitl', 'vith', 'vitg'],
                   help='V-JEPA 2 backbone: vitl (300M), vith (600M), vitg (1B)')
    g.add_argument('--vjepa2_resolution', type=int, default=256,
                   choices=[256, 384])
    g.add_argument('--pretrained_checkpoint', type=str, default=None,
                   help='Path to existing checkpoint to resume from '
                        '(overrides V-JEPA 2 download)')

    # ---- Model ----
    g = parser.add_argument_group('Model')
    g.add_argument('--img_size', type=int, default=224)
    g.add_argument('--num_frames', type=int, default=16)
    g.add_argument('--predictor_dim', type=int, default=1024)
    g.add_argument('--predictor_depth', type=int, default=12)
    g.add_argument('--predictor_heads', type=int, default=8)
    g.add_argument('--action_dim', type=int, default=7,
                   help='6 Cartesian + 1 gripper')
    g.add_argument('--state_dim', type=int, default=14,
                   help='7 joint + 6 Cartesian + 1 gripper')
    g.add_argument('--num_task_classes', type=int, default=2)
    g.add_argument('--predict_horizon', type=int, default=4,
                   help='Number of future steps to predict')

    # ---- Training ----
    g = parser.add_argument_group('Training')
    g.add_argument('--num_epochs', type=int, default=50)
    g.add_argument('--batch_size', type=int, default=4)
    g.add_argument('--learning_rate', type=float, default=3e-4,
                   help='Predictor / heads learning rate')
    g.add_argument('--encoder_lr', type=float, default=1e-5,
                   help='Encoder learning rate (lower for pretrained backbone)')
    g.add_argument('--weight_decay', type=float, default=0.05)
    g.add_argument('--warmup_ratio', type=float, default=0.05,
                   help='Fraction of total steps for LR warmup')
    g.add_argument('--grad_clip', type=float, default=1.0)
    g.add_argument('--ema_decay', type=float, default=0.999,
                   help='EMA decay for target encoder')
    g.add_argument('--num_workers', type=int, default=4)
    g.add_argument('--use_amp', action='store_true', default=False,
                   help='Use mixed-precision (fp16) training')
    g.add_argument('--use_grad_checkpoint', action='store_true', default=False,
                   help='Gradient checkpointing (saves memory)')

    # ---- Loss weights ----
    g = parser.add_argument_group('Loss Weights')
    g.add_argument('--lambda_latent', type=float, default=1.0)
    g.add_argument('--lambda_action', type=float, default=1.0)
    g.add_argument('--lambda_state', type=float, default=0.5)
    g.add_argument('--lambda_task', type=float, default=0.1)
    g.add_argument('--lambda_uncertainty', type=float, default=0.01)

    # ---- I/O ----
    g = parser.add_argument_group('I/O')
    g.add_argument('--save_dir', type=str, default='./checkpoints/world_model')
    g.add_argument('--save_every_steps', type=int, default=5000)
    g.add_argument('--device', type=str, default='auto')
    g.add_argument('--seed', type=int, default=42)

    args = parser.parse_args()

    # ---- Seed ----
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)

    # ---- Device ----
    if args.device == 'auto':
        if torch.cuda.is_available():
            args.device = 'cuda'
        elif hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
            args.device = 'mps'
        else:
            args.device = 'cpu'

    print(f"\n{'='*70}")
    print("DROID ACTION-CONDITIONED WORLD MODEL")
    print(f"V-JEPA 2 backbone: {args.vjepa2_size.upper()}")
    print(f"Dataset: {args.data_path} ({args.format})")
    print(f"Filter: episodes ≥ {MIN_EPISODE_SECONDS}s ({MIN_EPISODE_FRAMES} frames)")
    print(f"Target: {TARGET_HOURS} hours of data")
    print(f"Device: {args.device}")
    print(f"{'='*70}")

    # ================================================================
    # 1. DOWNLOAD V-JEPA 2 BACKBONE
    # ================================================================

    if args.pretrained_checkpoint:
        print(f"\n[1/4] Loading from checkpoint: {args.pretrained_checkpoint}")
        ckpt = torch.load(args.pretrained_checkpoint, map_location='cpu',
                          weights_only=False)
        if 'vjepa2_config' in ckpt:
            vjepa2_config = ckpt['vjepa2_config']
        else:
            # Infer from checkpoint
            vjepa2_config = {
                'embed_dim': args.predictor_dim,
                'depth': 24,
                'num_heads': 16,
            }
        vjepa2_sd = ckpt.get('encoder_state_dict', ckpt.get('model_state_dict', {}))
    else:
        print(f"\n[1/4] Downloading V-JEPA 2 {args.vjepa2_size.upper()} backbone ...")
        vjepa2_sd, vjepa2_config = download_vjepa2_backbone(
            args.vjepa2_size, args.vjepa2_resolution)

    # ================================================================
    # 2. BUILD MODEL
    # ================================================================

    print(f"\n[2/4] Building world model ...")
    print(f"  Encoder: {vjepa2_config['embed_dim']}d × {vjepa2_config['depth']}L "
          f"× {vjepa2_config['num_heads']}H")
    print(f"  Predictor: {args.predictor_dim}d × {args.predictor_depth}L "
          f"× {args.predictor_heads}H")
    print(f"  Action dim: {args.action_dim}  |  State dim: {args.state_dim}")

    model = DROIDActionConditionedWorldModel(
        img_size=args.img_size,
        num_frames=args.num_frames,
        tubelet_size=(2, 16, 16),
        encoder_dim=vjepa2_config['embed_dim'],
        encoder_depth=vjepa2_config['depth'],
        encoder_heads=vjepa2_config['num_heads'],
        predictor_dim=args.predictor_dim,
        predictor_depth=args.predictor_depth,
        predictor_heads=args.predictor_heads,
        action_dim=args.action_dim,
        state_dim=args.state_dim,
        num_task_classes=args.num_task_classes,
        temporal_scale=1.0,
        use_grad_checkpoint=args.use_grad_checkpoint,
    )

    # Load V-JEPA 2 weights into encoder
    if args.pretrained_checkpoint and 'model_state_dict' in ckpt:
        # Full model checkpoint — load everything
        missing, unexpected = model.load_state_dict(ckpt['model_state_dict'], strict=False)
        print(f"  Loaded full checkpoint (missing={len(missing)}, unexpected={len(unexpected)})")
    else:
        # Encoder-only weights from V-JEPA 2
        missing, unexpected = model.encoder.load_state_dict(vjepa2_sd, strict=False)
        print(f"  Loaded V-JEPA 2 encoder (missing={len(missing)}, unexpected={len(unexpected)})")
        if missing:
            print(f"    Missing (randomly init): {missing[:5]}"
                  f"{'...' if len(missing) > 5 else ''}")
        if unexpected:
            print(f"    Unexpected (ignored):    {unexpected[:5]}"
                  f"{'...' if len(unexpected) > 5 else ''}")

    total_params = sum(p.numel() for p in model.parameters()) / 1e6
    print(f"  Total parameters: {total_params:.1f}M")

    # EMA target encoder
    ema = EMAEncoder(model.encoder, decay=args.ema_decay)
    print(f"  EMA target encoder created (decay={args.ema_decay})")

    # ================================================================
    # 3. LOAD DATASET
    # ================================================================

    print(f"\n[3/4] Loading DROID dataset ...")
    print(f"  Format: {args.format}")
    print(f"  Camera: {args.camera}")
    print(f"  Filter: ≥{MIN_EPISODE_SECONDS}s ({MIN_EPISODE_FRAMES} frames at {DROID_FPS} Hz)")
    print(f"  Clip length: {args.num_frames} + {args.predict_horizon} "
          f"= {args.num_frames + args.predict_horizon} frames")

    dataset = create_dataset(args)
    dataloader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=(args.device == 'cuda'),
        drop_last=True,
        persistent_workers=(args.num_workers > 0),
    )

    print(f"  Clips: {len(dataset)}")
    print(f"  Batches/epoch: {len(dataloader)}")

    # ================================================================
    # 4. TRAIN
    # ================================================================

    print(f"\n[4/4] Starting training ...")
    train_action_conditioned_world_model(model, ema, dataloader, args)


if __name__ == "__main__":
    main()
